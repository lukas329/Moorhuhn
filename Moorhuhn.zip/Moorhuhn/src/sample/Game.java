package sample;

import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

import java.io.File;
import java.util.LinkedList;
import java.util.ListIterator;


public class Game extends Group {
    long counter = 200;
    ImageView background = new ImageView(new Image("sample/photos/background.jpg", 1400, 700, false, false));
    LinkedList <Chicken> chickens;
    static int shotsFired = 0;
    LinkedList<Bullet> bullets = new LinkedList<>();
    String input = "";
    Media reload = new Media(new File("src/sample/sounds/reload.wav").toURI().toString());
    MediaPlayer player;
    static int score = 0;
    Text points;

    public Game() {
        super();
        setFocusTraversable(true);
        setFocused(true);
        getChildren().add(background);
        chickens = new LinkedList<>();
        showBullets();
        setOnKeyPressed(e->input= e.getCode().toString());
        points = new Text();
        points.setFill(Color.WHITE);
        points.setFont(Font.font(null, FontWeight.BOLD, 32));
        points.setLayoutX(625);
        points.setLayoutY(670);
        getChildren().add(points);
    }

    public void update(double deltaTime){
        double difference = deltaTime/1000000000 * 30;
        createChicken();
        moveChicken(difference);
        removeChickenFromList();
        showBullets();
        handleInput(input);
        updateScore(score);
    }
    /*
    Vytvorenie sliepky na náhodnej Y pozícii
    aby sa nevytvárali každých 10 ms,  bude sa vytvárať každých 300 ms
    random služi na rozhodnutie, z ktorej strany sa vytvorí
     */
    public void createChicken(){
        counter +=10;
        Chicken chicken;
        if (counter %300 == 0 &&  chickens.size() <= 30) {
            int randomY = (int) (Math.random() * 600);
            double random = Math.random();
            if (random > .5)chicken = new Chicken(0, randomY);
            else chicken = new Chicken(1400, randomY);
            chickens.add(chicken);
            chickens.add(chicken);
            getChildren().add(chicken);
        }
    }
    /*
     * použitie iterátora na posun každého obrázku
     * rozlišujeme, na ktorej strane vznikne obrázok a podľa toho ho posúvame
     */
    public void moveChicken(double difference){
        ListIterator <Chicken> listIterator = chickens.listIterator(0);
        while (listIterator.hasNext()){
            Chicken chicken = listIterator.next();
            if (chicken.stav == 0) {
                if (chicken.getStartX() == 0){
                    chicken.move(difference);
                }
                else{
                    chicken.move(difference * -1);
                }
            }
            if (chicken.stav == 1) chicken.moveDown(difference);
        }

    }
    /*
     * vymazanie spritov z listu
     * iba tie ktoré boli odstránené z obrazovky, aby sa mohli tvoriť nové
     */
    public void removeChickenFromList(){
        ListIterator <Chicken> listIterator = chickens.listIterator(0);
        while (listIterator.hasNext()) {
            Chicken chicken = listIterator.next();
            if (chicken.deleted){
                listIterator.remove();
            }
        }
    }
    /*
    vykreslenie nábojov vzhľadom na počet vystrelených nábojov
     */
    public void showBullets(){
        ListIterator <Bullet> listIterator = bullets.listIterator(0);
        while (listIterator.hasNext()){
            Bullet bullet = listIterator.next();
            bullet.remove();
            listIterator.remove();
        }
        int x = 1100;
        for (int i = 0; i < (10 - shotsFired); i++){
            Bullet bullet = new Bullet(x);
            getChildren().add(bullet);
            bullets.add(bullet);
            x += 20;
        }
    }

    public void handleInput(String input){
        switch (input){
            case "SPACE" : {
                player = new MediaPlayer(reload);
                shotsFired = 0;
                player.play();
            }
        }
        this.input ="";
    }
    public void updateScore(int sc){
        points.setText("Score: " + sc);
    }
}
