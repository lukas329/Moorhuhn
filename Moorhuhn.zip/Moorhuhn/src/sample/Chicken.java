package sample;

import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;


import java.io.File;
import java.util.ArrayList;

public class Chicken extends ImageView{

    enum Type {
        SMALL, MEDIUM, BIG
    }

    enum Direction {
        LEFT, RIGHT
    }

    int width, height;
    private Image [] images;
    Media shot = new Media(new File("src/sample/sounds/gunshot.wav").toURI().toString());
    Media empty = new Media(new File("src/sample/sounds/empty.wav").toURI().toString());
    MediaPlayer player = new MediaPlayer(shot);
    int stav, startX;
    boolean deleted = false;

    private int number = 0;
    public Type type;
    public Direction direction;
    int skuska = 0;

    public Chicken(int x, int y) {
        super();
        startX = x;

        /*
        podľa toho v akej výške vznikli im priradíme veľkosť -> vyššie sú vzdialenejšie a preto sú menšie
        ale získava sa za nich viac bodov
         */
        if (y < 200) {
            width = height = 50;
            type = Type.SMALL;
        }
        if (y >= 200 && y < 400) {
            width = height = 70;
            type = Type.MEDIUM;
        }
        if (y >= 400 && y <= 600){
            width = height = 100;
            type = Type.BIG;
        }
        images = new Image[4];
        /*
        načítanie obrázkov
         */
        for (int i  = 0; i < 4; i++){
            images[i] = new Image("sample/photos/" + i + ".png", width, height, false, false);
        }

        stav = 0;
        //určenie kde vznikli a podľa toho sa neskor určuje pohyb
        if (x == 0) {
            direction = Direction.LEFT;
            setImage(images[0]);
        }
        else if (x == 1400){
            direction = Direction.RIGHT;
            setImage(images[2]);
        }

        setLayoutY(y);
        setLayoutX(x);
        setFocusTraversable(true);
        // rozlišujeme 3 veľkosti kvôli určeniu bodov

        setOnMouseClicked(e-> {
            if (Game.shotsFired < 10){
                Game.shotsFired++;
                if (type == Type.SMALL)Game.score += 25;
                if (type == Type.MEDIUM)Game.score += 10;
                if (type == Type.BIG)Game.score += 5;
                stav = 1;
                player = new MediaPlayer(shot);
            }
            else {
                player = new MediaPlayer(empty);
            }
            player.setVolume(.07);
            player.play();
        });
    }
    /*
    pohyb po X suúradnici
    náhodný pohyb po Y súradnici
     */
    public void move(double difference) {
        draw();
        setLayoutX(getLayoutX() + difference);
        double random = Math.random();
        if (random > .4)setLayoutY(getLayoutY() - difference);
        else if (random < .6)setLayoutY(getLayoutY() + difference);
        if (getLayoutY() <0) setLayoutY(.5);
        if (getLayoutY() > 600)setLayoutY(600);
        delete();
    }
    /*
    po kliknutí resp. zastrelení sa zmeni obrázok a pohybuje sa iba smerom dole
     */
    public void moveDown(double difference) {
        setImage(new Image("sample/photos/Dead.png", 50, 25, false, false));
        setLayoutY(getLayoutY() + .8 + difference);
        delete();
    }
    /*
    premázavnie ak obrázok výjde mimo plochy
     */
    public void delete() {
        if (getLayoutX() > 1400|| getLayoutX() < - width || getLayoutY() > 700) {
            if ((getParent()) != null){
                ((Group)getParent()).getChildren().remove(this);
                deleted = true;
            }
        }
    }
    /*
    určenie ktorý obrázok sa má vykresliť
     */
    public void nextImage() {
        if (direction == Direction.LEFT) number = (number + 1) % 2;
        if (direction == Direction.RIGHT) number = 2 + (number + 1) % 2;
    }
    /*
    vykreslenie obrázkov, ktoré nefunguje napriek tomu, number sa mení
     */
    public void draw(){
        nextImage();
        setImage(images[number]);
    }
    public int getStartX() {
        return startX;
    }
}
