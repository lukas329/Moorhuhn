package sample;

import javafx.animation.AnimationTimer;

public class Timer extends AnimationTimer {
    private Game game;
    private static long lastNanoTime;
    public Timer(Game game) {
        super();
        this.game = game;
    }

    @Override
    public void start() {
        lastNanoTime = System.nanoTime();
        super.start();
    }

    @Override
    public void handle(long l) {
        game.update(l - lastNanoTime);
        lastNanoTime = l;
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
