package sample;

import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Bullet extends ImageView {
    public Bullet(int x) {
        super();
        setLayoutX(x);
        setLayoutY(600);
        setImage(new Image("sample/photos/bullet.png", 10, 50, false, false));
    }
    public void remove(){
        if (getParent() != null)((Group)getParent()).getChildren().remove(this);
    }
}
