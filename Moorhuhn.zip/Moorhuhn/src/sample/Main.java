package sample;


import javafx.application.Application;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Group root = new Group();
        Scene scene = new Scene(root, 1400, 700);

        Image welcome = new Image("sample/photos/welcome.png", 1400, 700, false, false);
        ImageView view = new ImageView(welcome);
        Button btn = new Button("S T A R T");
        btn.setLayoutX(525);
        btn.setLayoutY(450);
        btn.setMinWidth(300);
        btn.setStyle("-fx-background-color: #2ea48b; ");
        root.getChildren().addAll(view, btn);
        btn.setOnMouseClicked(e->{
            root.getChildren().remove(btn);
            scene.setCursor(Cursor.CROSSHAIR);
            btn.setFocusTraversable(false);
            Game game = new Game();
            Timer timer = new Timer(game);
            timer.start();
            root.getChildren().add(game);
        });


        primaryStage.setTitle("Moorhuhn");
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
